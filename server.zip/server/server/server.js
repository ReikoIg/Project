// server.js
const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcrypt'); // Для хеширования паролей
const jwt = require('jsonwebtoken'); // Для генерации токенов

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(bodyParser.json());

const dbPath = path.join(__dirname, 'newdb.sqlite');

// Проверяем, существует ли файл базы данных; если нет, создаем его
if (!fs.existsSync(dbPath)) {
    fs.writeFileSync(dbPath, '');  // Создание нового файла базы данных
}

const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error("Не удалось подключиться к базе данных:", err.message);
    } else {
        console.log("Подключение к базе данных успешно!");
    }
});

// Создание таблицы пользователей
db.serialize(() => {
    db.run("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE, password TEXT NOT NULL, role TEXT DEFAULT 'user')", (err) => {
        if (err) {
            console.error("Ошибка при создании таблицы:", err.message);
        } else {
            console.log("Таблица пользователей создана или уже существует.");
        }
    });
});

// Эндпоинт для регистрации пользователей
app.post('/register', async (req, res) => {
    const { username, password, role } = req.body; // Получаем роль из запроса

    // Проверяем, что роль допустима
    if (role !== 'user' && role !== 'admin') {
        return res.status(400).send('Недопустимая роль. Доступны только "user" или "admin".');
    }

    try {
        // Хешируем пароль
        const hashedPassword = await bcrypt.hash(password, 10);
        
        // Подготовка SQL-запроса на добавление пользователя
        const stmt = db.prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
        stmt.run([username, hashedPassword, role], function(err) {
            if (err) {
                console.error("Ошибка при регистрации:", err.message);
                return res.status(500).send('Ошибка регистрации');
            }
            res.status(200).send('Пользователь зарегистрирован с ID: ' + this.lastID);
        });
        stmt.finalize();
    } catch (error) {
        console.error("Ошибка хеширования пароля:", error.message);
        return res.status(500).send('Ошибка регистрации');
    }
});

// Эндпоинт для входа пользователей
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    db.get("SELECT * FROM users WHERE username = ?", [username], async (err, row) => {
        if (err) {
            console.error("Ошибка при входе:", err.message);
            return res.status(500).send('Ошибка входа');
        }
        if (row && await bcrypt.compare(password, row.password)) {
            const token = jwt.sign({ id: row.id, username: row.username, role: row.role }, 'your_secret_key', { expiresIn: '1h' });
            return res.status(200).json({ message: 'Успешный вход', token, role: row.role });
        } else {
            return res.status(401).send('Неправильный логин или пароль');
        }
    });
});

// Эндпоинт для получения списка пользователей
app.get('/users', (req, res) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).send('Необходима авторизация');
    }

    jwt.verify(token, 'your_secret_key', (err, user) => {
        if (err) {
            return res.status(403).send('Ошибка авторизации');
        }

        if (user.role !== 'admin') {
            return res.status(403).send('Доступ запрещен: недостаточно прав');
        }

        db.all("SELECT id, username, role FROM users", [], (err, rows) => {
            if (err) {
                console.error("Ошибка при получении пользователей:", err.message);
                return res.status(500).send('Ошибка получения пользователей');
            }
            res.json(rows); // Возвращаем массив пользователей
        });
    });
});

// Эндпоинт для добавления нового администратора
app.post('/add-admin', async (req, res) => {
    const { username, password } = req.body;

    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).send('Необходима авторизация');
    }

    jwt.verify(token, 'your_secret_key', async (err, user) => {
        if (err) {
            return res.status(403).send('Ошибка авторизации');
        }
        
        if (user.role !== 'admin') {
            return res.status(403).send('Доступ запрещен: недостаточно прав');
        }

        try {
            const hashedPassword = await bcrypt.hash(password, 10);
            const stmt = db.prepare("INSERT INTO users (username, password, role) VALUES (?, ?, 'admin')");
            stmt.run([username, hashedPassword], function(err) {
                if (err) {
                    console.error("Ошибка при добавлении администратора:", err.message);
                    return res.status(500).send('Ошибка добавления администратора');
                }
                res.status(200).send('Администратор добавлен с ID: ' + this.lastID);
            });
            stmt.finalize();
        } catch (error) {
            console.error("Ошибка хеширования пароля:", error.message);
            return res.status(500).send('Ошибка добавления администратора');
        }
    });
});

// Запуск сервера
app.listen(PORT, () => {
    console.log(`Сервер работает на http://localhost:${PORT}`);
});         

app.delete('/users/:id', (req, res) => {
    const id = req.params.id;

    const stmt = db.prepare("DELETE FROM users WHERE id = ?");
    stmt.run(id, function(err) {
        if (err) {
            return res.status(500).send('Ошибка удаления пользователя');
        }
        res.status(200).send('Пользователь успешно удалён с ID: ' + id);
    });
    stmt.finalize();
});