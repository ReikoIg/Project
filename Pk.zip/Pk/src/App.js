import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import AboutUs from "./components/AboutUs";
import Contacts from "./components/Contacts";
import Login from "./components/Login";
import Register from "./components/Register";
import Welcome from "./components/Welcome"; 
import AdminPanel from "./components/AdminPanel"; // Импортируем новый компонент
import CreateUser from "./components/CreateUser"; // Импортируем страницу создания пользователя
import EditUser from "./components/EditUser";

function App() {
    return (
        <Router>
            <div className="wrapper">
                <Header />
                <Routes>
                    <Route path="/" element={<AboutUs />} />
                    <Route path="/contacts" element={<Contacts />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/register" element={<Register />} />
                    <Route path="/welcome" element={<Welcome />} />
                    <Route path="/admin-panel" element={<AdminPanel />} /> 
                    <Route path="/create-user" element={<CreateUser />} /> 
                    <Route path="/edit-user/:id" element={<EditUser />} /> 
                </Routes>
                <Footer />
            </div>
        </Router>
    );
}

export default App;