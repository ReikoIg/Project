import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const AdminPanel = () => {
    const navigate = useNavigate();
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedUserIds, setSelectedUserIds] = useState([]);
    const [error, setError] = useState(null);

    const parseJwt = (token) => {
        const base64Url = token.split('.')[1];
        const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        return JSON.parse(window.atob(base64));
    };

    const token = localStorage.getItem('token');
    const isAdmin = token ? parseJwt(token).role === 'admin' : false;

    useEffect(() => {
        const fetchUsers = async () => {
            if (!isAdmin) {
                navigate('/welcome');
                return;
            }

            try {
                const response = await fetch('http://localhost:5000/users', {
                    method: 'GET',
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });

                if (!response.ok) {
                    throw new Error('Ошибка при загрузке пользователей');
                }

                const data = await response.json();
                setUsers(data);
            } catch (err) {
                setError(err.message);
            } finally {
                setLoading(false);
            }
        };

        fetchUsers();
    }, [isAdmin, navigate, token]);

    const handleRowClick = (userId) => {
        if (selectedUserIds.includes(userId)) {
            setSelectedUserIds(selectedUserIds.filter((id) => id !== userId)); // Удаляем из выделенных
        } else {
            setSelectedUserIds([...selectedUserIds, userId]); // Добавляем в выделенные
        }
    };

    const handleDeleteSelected = async () => {
        if (selectedUserIds.length === 0) {
            alert('Выберите хотя бы одну учетную запись для удаления.');
            return;
        }

        if (window.confirm('Вы точно хотите удалить выбранные учетные записи?')) {
            try {
                await Promise.all(selectedUserIds.map(async (userId) => {
                    const response = await fetch(`http://localhost:5000/users/${userId}`, {
                        method: 'DELETE',
                        headers: {
                            Authorization: `Bearer ${token}`,
                        },
                    });

                    if (!response.ok) {
                        console.error('Ошибка при удалении учетной записи с ID:', userId);
                    }
                }));

                alert('Выбранные учетные записи успешно удалены!');
                setUsers(users.filter(user => !selectedUserIds.includes(user.id))); 
                setSelectedUserIds([]); // Очищаем выделенные ID
            } catch (error) {
                console.error('Ошибка:', error);
            }
        }
    };

    if (loading) {
        return <div>Загрузка...</div>;
    }

    if (error) {
        return <div style={{ color: 'red' }}>{error}</div>;
    }

    return (
        <div>
            <h1 id='Panel'>Панель администратора</h1>
            <table id='Stol'>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Логин</th>
                        <th>Роль</th>
                    </tr>
                </thead>
                <tbody>
                    {users.map((user) => (
                        <tr 
                            key={user.id}
                            onClick={() => handleRowClick(user.id)} 
                            style={{ backgroundColor: selectedUserIds.includes(user.id) ? '#d3d3d3' : 'transparent', cursor: 'pointer' }} // Выделение выбранных строк
                        >
                            <td>{user.id}</td>
                            <td>{user.username}</td>
                            <td>{user.role}</td>
                        </tr>
                    ))}
                </tbody>
            </table>

            <div id="Knopki">
                <button className="action-button" onClick={() => navigate('/create-user')}>Создать учетную запись</button>
                <button 
                    className="action-button" 
                    onClick={() => {
                        if (selectedUserIds.length === 1) {
                            navigate(`/edit-user/${selectedUserIds[0]}`);
                        } else {
                            alert('Выберите ровно одну учетную запись для редактирования.');
                        }
                    }}
                >
                    Редактировать учетную запись
                </button>
                <button className="action-button" onClick={handleDeleteSelected}>Удалить учетные записи</button>
            </div>
        </div>
    );
};

export default AdminPanel;