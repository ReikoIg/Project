import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

const EditUser = () => {
    const { id } = useParams(); // Получаем ID пользователя из параметров URL
    const navigate = useNavigate();
    const token = localStorage.getItem('token');

    const [userData, setUserData] = useState({
        username: '',
        password: '',
        role: '',
        additionalFields: [], // Для хранения дополнительных полей
    });
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchUser = async () => {
            try {
                const response = await fetch(`http://localhost:5000/users/${id}`, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });

                if (!response.ok) {
                    throw new Error('Ошибка при загрузке данных пользователя');
                }

                const data = await response.json();
                setUserData({
                    username: data.username,
                    password: data.password,
                    role: data.role,
                    additionalFields: data.additionalFields || [], // Необходимо, если у вас есть дополнительные поля
                });
            } catch (err) {
                setError(err.message);
            } finally {
                setLoading(false);
            }
        };

        fetchUser();
    }, [id, token]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setUserData((prevData) => ({ ...prevData, [name]: value }));
    };

    const handleAddField = () => {
        setUserData((prevData) => ({
            ...prevData,
            additionalFields: [...prevData.additionalFields, { fieldName: '', fieldValue: '' }],
        }));
    };

    const handleAdditionalFieldChange = (index, e) => {
        const { name, value } = e.target;
        const fields = [...userData.additionalFields];
        fields[index][name] = value;
        setUserData((prevData) => ({
            ...prevData,
            additionalFields: fields,
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch(`http://localhost:5000/users/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify(userData),
            });

            if (!response.ok) {
                throw new Error('Ошибка при обновлении учетной записи');
            }

            alert('Учетная запись успешно обновлена!');
            navigate('/admin'); // Перенаправляем обратно в панель администратора
        } catch (err) {
            setError(err.message);
        }
    };

    if (loading) {
        return <div>Загрузка...</div>;
    }

    return (
        <div>
            <h1>Редактирование учетной записи</h1>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <form onSubmit={handleSubmit}>
                <div>
                    <label htmlFor="username">Логин:</label>
                    <input
                        type="text"
                        id="username"
                        name="username"
                        value={userData.username}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div>
                    <label htmlFor="password">Пароль:</label>
                    <input
                        type="password"
                        id="password"
                        name="password"
                        value={userData.password}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div>
                    <label htmlFor="role">Роль:</label>
                    <input
                        type="text"
                        id="role"
                        name="role"
                        value={userData.role}
                        onChange={handleChange}
                        required
                    />
                </div>
                {userData.additionalFields.map((field, index) => (
                    <div key={index}>
                        <input
                            type="text"
                            placeholder="Имя поля"
                            name="fieldName"
                            value={field.fieldName || ''}
                            onChange={(e) => handleAdditionalFieldChange(index, e)}
                        />
                        <input
                            type="text"
                            placeholder="Значение поля"
                            name="fieldValue"
                            value={field.fieldValue || ''}
                            onChange={(e) => handleAdditionalFieldChange(index, e)}
                        />
                    </div>
                ))}
                <div id="Knopki3">
                <button type="button" onClick={handleAddField}>Добавить дополнительное поле</button>
                <button type="submit">Сохранить изменения</button>
                </div>
            </form>
        </div>
    );
};

export default EditUser;