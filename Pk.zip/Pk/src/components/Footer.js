import React from "react";

export default function Footer() {
    return (
        <footer>
            Все права защищены 2024 &copy;
        </footer>
    )
}