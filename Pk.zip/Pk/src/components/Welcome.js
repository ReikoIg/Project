import React from 'react';

export default function Welcome() {
    return (
        <div>
            <h1 id='Wel'>Добро пожаловать!</h1>
            <br></br>
            <p>Вы успешно вошли в систему!</p>
        </div>
    );
}