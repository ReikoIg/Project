﻿"""
Flask веб-приложение для анализа парковки с YOLO
Версия с 3 режимами отображения и фоновой обработкой видео
"""

from flask import Flask, render_template, request, jsonify, send_from_directory, send_file
from werkzeug.utils import secure_filename
import os
import cv2
from pathlib import Path
from datetime import datetime
import json
from ultralytics import YOLO
import numpy as np
import threading
import time
import io
import zipfile

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 500 * 1024 * 1024  # 500 MB max
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['RESULTS_FOLDER'] = 'results'
app.config['STATIC_FOLDER'] = 'static'

# Создаём необходимые папки
for folder in [app.config['UPLOAD_FOLDER'], app.config['RESULTS_FOLDER']]:
    os.makedirs(folder, exist_ok=True)

# Загрузка моделей YOLO
# Модель для обычных фото (вид сверху)
MODEL_REGULAR_PATH = r"C:\Users\2\Desktop\Static2.0\static\maschin_model\best.pt"
model_regular = YOLO(MODEL_REGULAR_PATH)

# Модель для спутниковых снимков (TIF формат)
MODEL_SATELLITE_PATH = r"C:\Users\2\Desktop\Static2.0\static\maschin_model\best2.pt"
model_satellite = YOLO(MODEL_SATELLITE_PATH)

# Настройки детекции
DETECTION_SETTINGS = {
    'image_conf': 0.30,  # Порог уверенности для ФОТО (оптимально для спутниковых снимков)
    'satellite_conf': 0.07,  # Порог для спутниковых снимков (понижен до 0.07 для лучшего обнаружения)
    'video_conf': 0.25,  # Порог уверенности для ВИДЕО (ниже, чтобы не пропускать места)
    'iou': 0.45,   # IoU порог
    'max_det': 500,  # Увеличено для плотных парковок
}

# Названия классов
CLASS_NAMES = {
    0: 'Occupied',
    1: 'Free',
}

# Цвета для классов (BGR)
CLASS_COLORS = {
    0: (0, 0, 255),    # Красный - занято
    1: (0, 255, 0),    # Зелёный - свободно
}

# Режимы отображения
DISPLAY_MODES = {
    'all': 'Все места',
    'occupied': 'Только занятые',
    'free': 'Только свободные'
}

# Расширения для обычных фото
REGULAR_IMAGE_EXTENSIONS = {'png', 'jpg', 'jpeg', 'bmp', 'gif'}
# Расширения для спутниковых снимков
SATELLITE_IMAGE_EXTENSIONS = {'tif', 'tiff'}
# Все допустимые расширения изображений
ALLOWED_IMAGE_EXTENSIONS = REGULAR_IMAGE_EXTENSIONS | SATELLITE_IMAGE_EXTENSIONS
ALLOWED_VIDEO_EXTENSIONS = {'mp4', 'avi', 'mov', 'mkv'}

# Глобальная переменная для отслеживания процесса обработки видео
video_processing_status = {
    'is_processing': False,
    'progress': 0,
    'current_frame': 0,
    'total_frames': 0,
    'message': '',
    'result_filename': '',  # ДОБАВЛЕНО: имя результата
    'should_stop': False  # Флаг для остановки
}

# Глобальная переменная для отслеживания пакетной обработки фото
batch_processing_status = {
    'is_processing': False,
    'progress': 0,
    'current_image': 0,
    'total_images': 0,
    'message': '',
    'results': [],  # Список результатов
    'session_id': '',  # ID сессии обработки
    'should_stop': False  # Флаг для остановки
}


def allowed_file(filename, file_type='image'):
    """Проверка допустимого расширения файла"""
    if '.' not in filename:
        return False
    ext = filename.rsplit('.', 1)[1].lower()
    if file_type == 'image':
        return ext in ALLOWED_IMAGE_EXTENSIONS
    elif file_type == 'video':
        return ext in ALLOWED_VIDEO_EXTENSIONS
    return False


def draw_boxes_by_mode(image, results, mode='all', show_labels=False, show_conf=False, is_satellite=False):
    """
    Отрисовка боксов в зависимости от режима
    
    Args:
        image: Изображение
        results: Результаты детекции YOLO
        mode: Режим отображения ('all', 'occupied', 'free')
        show_labels: Показывать подписи (по умолчанию False)
        show_conf: Показывать уверенность (по умолчанию False)
        is_satellite: Спутниковый снимок (тонкие прозрачные контуры) или обычное фото (толстые контуры)
    """
    img = image.copy()
    
    # Для спутниковых снимков - создаём прозрачный слой
    if is_satellite:
        overlay = img.copy()
    
    for box in results[0].boxes:
        cls = int(box.cls[0])
        
        # Фильтрация по режиму
        if mode == 'occupied' and cls != 0:  # Показываем только занятые
            continue
        elif mode == 'free' and cls != 1:  # Показываем только свободные
            continue
        # mode == 'all' - показываем всё
        
        x1, y1, x2, y2 = map(int, box.xyxy[0])
        conf = float(box.conf[0])
        
        color = CLASS_COLORS.get(cls, (255, 255, 255))
        class_name = CLASS_NAMES.get(cls, f'Class {cls}')
        
        if is_satellite:
            # Для спутниковых снимков - тонкие прозрачные контуры (1px)
            cv2.rectangle(overlay, (x1, y1), (x2, y2), color, 1)
        else:
            # Для обычных фото - толстые яркие контуры (3px)
            cv2.rectangle(img, (x1, y1), (x2, y2), color, 3)
        
        if show_labels:
            # Формируем текст
            if show_conf:
                label = f'{class_name} {conf:.2f}'
            else:
                label = class_name
            
            # Настройки текста
            font = cv2.FONT_HERSHEY_SIMPLEX
            font_scale = 0.7
            thickness = 2
            
            # Размер текста
            (text_width, text_height), baseline = cv2.getTextSize(
                label, font, font_scale, thickness
            )
            
            # Фон для текста
            target_img = overlay if is_satellite else img
            cv2.rectangle(
                target_img,
                (x1, y1 - text_height - baseline - 10),
                (x1 + text_width + 10, y1),
                color,
                -1
            )
            
            # Текст
            cv2.putText(
                target_img,
                label,
                (x1 + 5, y1 - 5),
                font,
                font_scale,
                (255, 255, 255),
                thickness,
                cv2.LINE_AA
            )
    
    # Для спутниковых снимков - накладываем прозрачный слой (40% непрозрачности)
    if is_satellite:
        img = cv2.addWeighted(overlay, 0.4, img, 0.6, 0)
    
    return img


def create_geojson(results, image_shape):
    """
    Создаёт GeoJSON с координатами разметки
    
    Args:
        results: Результаты детекции YOLO
        image_shape: Размер изображения (height, width, channels)
    
    Returns:
        dict: GeoJSON объект
    """
    height, width = image_shape[:2]
    
    features = []
    
    for idx, box in enumerate(results[0].boxes):
        cls = int(box.cls[0])
        conf = float(box.conf[0])
        x1, y1, x2, y2 = map(float, box.xyxy[0])
        
        # Центр bbox
        center_x = (x1 + x2) / 2
        center_y = (y1 + y2) / 2
        
        # Размеры bbox
        bbox_width = x2 - x1
        bbox_height = y2 - y1
        
        # Создаём Polygon из координат bbox
        # GeoJSON использует [longitude, latitude], но для пикселей используем [x, y]
        coordinates = [[
            [x1, y1],  # Верхний левый
            [x2, y1],  # Верхний правый
            [x2, y2],  # Нижний правый
            [x1, y2],  # Нижний левый
            [x1, y1]   # Замыкаем полигон
        ]]
        
        feature = {
            "type": "Feature",
            "id": idx,
            "geometry": {
                "type": "Polygon",
                "coordinates": coordinates
            },
            "properties": {
                "object_id": idx,
                "class": CLASS_NAMES.get(cls, f'Class {cls}'),
                "class_id": cls,
                "confidence": round(conf, 4),
                "bbox": {
                    "x1": round(x1, 2),
                    "y1": round(y1, 2),
                    "x2": round(x2, 2),
                    "y2": round(y2, 2)
                },
                "center": {
                    "x": round(center_x, 2),
                    "y": round(center_y, 2)
                },
                "size": {
                    "width": round(bbox_width, 2),
                    "height": round(bbox_height, 2)
                },
                "status": "occupied" if cls == 0 else "free",
                "color": "red" if cls == 0 else "green"
            }
        }
        
        features.append(feature)
    
    geojson = {
        "type": "FeatureCollection",
        "metadata": {
            "image_width": width,
            "image_height": height,
            "total_detections": len(features),
            "occupied_count": sum(1 for f in features if f['properties']['class_id'] == 0),
            "free_count": sum(1 for f in features if f['properties']['class_id'] == 1),
            "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            "coordinate_system": "image_pixels"
        },
        "features": features
    }
    
    return geojson


def analyze_image_api(image_path, mode='all', conf=None, iou=None):
    """
    Анализ изображения с поддержкой режимов отображения
    Автоматически выбирает модель и порог в зависимости от формата файла:
    - TIF/TIFF -> best2.pt + очень низкий порог 0.01 (для спутниковых снимков с тенями)
    - Остальные -> best.pt + стандартный порог 0.30 (для обычных фото)
    """
    iou = iou if iou is not None else DETECTION_SETTINGS['iou']
    
    # Определяем, какую модель и порог использовать
    file_extension = Path(image_path).suffix.lower().lstrip('.')
    
    if file_extension in SATELLITE_IMAGE_EXTENSIONS:
        # Используем модель для спутниковых снимков с НИЗКИМ порогом
        selected_model = model_satellite
        # Если порог не задан явно, используем низкий порог для спутников
        conf = conf if conf is not None else DETECTION_SETTINGS['satellite_conf']
        model_type = f'satellite (best2.pt, conf={conf})'
        is_satellite = True
        print(f"🛰️ Спутниковый снимок: {file_extension.upper()} | Порог confidence={conf} | Контуры: тонкие (1px) прозрачные (40%)")
    else:
        # Используем модель для обычных фото со стандартным порогом
        selected_model = model_regular
        conf = conf if conf is not None else DETECTION_SETTINGS['image_conf']
        model_type = f'regular (best.pt, conf={conf})'
        is_satellite = False
        print(f"📷 Обычное фото: {file_extension.upper()} | Порог confidence={conf} | Контуры: толстые (3px) яркие")
    
    # Детекция с выбранной моделью
    results = selected_model.predict(
        image_path,
        conf=conf,
        iou=iou,
        max_det=DETECTION_SETTINGS['max_det'],
        verbose=False
    )
    
    # Подсчёт статистики
    occupied = sum(1 for box in results[0].boxes if int(box.cls[0]) == 0)
    free = sum(1 for box in results[0].boxes if int(box.cls[0]) == 1)
    total = occupied + free
    occupancy_rate = (occupied / total * 100) if total > 0 else 0
    
    # Загрузка изображения
    img = cv2.imread(image_path)
    if img is None:
        return None
    
    # Отрисовка с учётом режима (БЕЗ текста и цифр уверенности)
    annotated = draw_boxes_by_mode(img, results, mode=mode, show_labels=False, show_conf=False, is_satellite=is_satellite)
    
    # Сохранение результата ВСЕГДА в PNG формате
    filename = Path(image_path).stem  # Имя без расширения
    result_path = os.path.join(app.config['RESULTS_FOLDER'], f'result_{filename}.png')
    cv2.imwrite(result_path, annotated)
    
    # Создаём GeoJSON с координатами разметки
    geojson_data = create_geojson(results, img.shape)
    geojson_filename = f'result_{filename}.geojson'
    geojson_path = os.path.join(app.config['RESULTS_FOLDER'], geojson_filename)
    
    with open(geojson_path, 'w', encoding='utf-8') as f:
        json.dump(geojson_data, f, ensure_ascii=False, indent=2)
    
    return {
        'total_spots': total,
        'occupied': occupied,
        'free': free,
        'occupancy_rate': round(occupancy_rate, 2),
        'result_image': f'result_{filename}.png',
        'geojson_file': geojson_filename,
        'detections_count': len(results[0].boxes),
        'model_used': model_type,
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }



def get_best_codec_for_browser():
    """
    Find best codec for browser playback
    Priority: H264 (avc1) > X264 > mp4v
    """
    codecs_priority = [
        ('avc1', 'H.264 (AVC1) - best for browsers'),
        ('H264', 'H.264'),  
        ('X264', 'X.264'),
        ('mp4v', 'MPEG-4 Part 2 - fallback')
    ]
    
    for codec_str, description in codecs_priority:
        try:
            fourcc = cv2.VideoWriter_fourcc(*codec_str)
            temp_path = 'temp_test_codec.mp4'
            test_writer = cv2.VideoWriter(temp_path, fourcc, 1, (100, 100))
            
            if test_writer.isOpened():
                test_frame = np.zeros((100, 100, 3), dtype=np.uint8)
                test_writer.write(test_frame)
                test_writer.release()
                
                if os.path.exists(temp_path) and os.path.getsize(temp_path) > 0:
                    os.remove(temp_path)
                    print(f"Codec selected: {codec_str} - {description}")
                    return fourcc, codec_str
                    
            test_writer.release()
            if os.path.exists(temp_path):
                os.remove(temp_path)
                
        except Exception as e:
            continue
    
    print("WARNING: Using fallback codec mp4v")
    return cv2.VideoWriter_fourcc(*'mp4v'), 'mp4v'
def process_video_background(video_path, mode='all', detect_interval=1.0):
    """
    Фоновая обработка видео с сохранением в results/
    Для видео всегда используется модель для обычных фото (best.pt)
    
    Args:
        video_path: Путь к видео
        mode: Режим отображения
        detect_interval: Интервал детекции в секундах (по умолчанию 1.0 = каждую секунду)
    """
    global video_processing_status
    
    try:
        video_processing_status['is_processing'] = True
        video_processing_status['progress'] = 0
        video_processing_status['message'] = 'Начало обработки...'
        
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            video_processing_status['message'] = 'Ошибка: не удалось открыть видео'
            return None
        
        # Параметры видео
        original_fps = int(cap.get(cv2.CAP_PROP_FPS))
        output_fps = min(15, original_fps)  # Снижаем FPS
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        
        # Рассчитываем, каждый какой кадр детектировать (на основе интервала)
        detect_every_n_frames = int(original_fps * detect_interval)
        if detect_every_n_frames < 1:
            detect_every_n_frames = 1
        
        video_processing_status['total_frames'] = total_frames
        
        # Путь для сохранения результата
        filename = Path(video_path).name
        result_filename = f'result_{Path(filename).stem}.mp4'
        result_path = os.path.join(app.config['RESULTS_FOLDER'], result_filename)
        
        # СОХРАНЯЕМ ИМЯ РЕЗУЛЬТАТА В СТАТУС
        video_processing_status['result_filename'] = result_filename
        
        # Создаём видео-писатель
        fourcc, codec_name = get_best_codec_for_browser()
        out = cv2.VideoWriter(result_path, fourcc, output_fps, (width, height))        
        if not out.isOpened():
            print(f"ERROR: Failed to create VideoWriter with codec {codec_name}")
            video_processing_status['message'] = 'Error: failed to create writer'
            cap.release()
            return None
        
        frame_number = 0
        frames_written = 0
        frame_stats = []
        fps_skip = max(1, original_fps // output_fps)
        
        # Переменная для хранения последней детекции
        last_results = None
        
        print(f"\n{'='*60}")
        print(f"🎬 ОБРАБОТКА ВИДЕО: {filename}")
        print(f"{'='*60}")
        print(f"📊 Параметры:")
        print(f"    Codec: {codec_name}")
        print(f"   • Оригинальный FPS: {original_fps}")
        print(f"   • Выходной FPS: {output_fps}")
        print(f"   • Всего кадров: {total_frames}")
        print(f"   • Режим отображения: {DISPLAY_MODES.get(mode, mode)}")
        print(f"   • Детекция каждый {detect_every_n_frames}-й кадр (каждые {detect_interval} сек.)")
        print(f"   • Разметка: на ВСЕХ кадрах (используется последняя детекция)")
        print(f"   • Порог уверенности для видео: {DETECTION_SETTINGS['video_conf']}")
        print(f"   • Результат: {result_filename}")
        print(f"{'='*60}\n")
        
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
            
            # Проверяем флаг остановки
            if video_processing_status['should_stop']:
                print(f"\n⛔ Остановка обработки видео по запросу пользователя!")
                video_processing_status['message'] = 'Остановлено пользователем'
                video_processing_status['should_stop'] = False  # Сбрасываем флаг
                break
            
            # Пропускаем кадры для снижения FPS
            if frame_number % fps_skip != 0:
                frame_number += 1
                continue
            
            # Обрабатываем каждый detect_every_n_frames-й кадр
            if frame_number % detect_every_n_frames == 0:
                # Детекция с порогом для видео (используем модель для обычных фото)
                results = model_regular.predict(
                    frame,
                    conf=DETECTION_SETTINGS['video_conf'],
                    iou=DETECTION_SETTINGS['iou'],
                    max_det=DETECTION_SETTINGS['max_det'],
                    verbose=False
                )
                
                # Сохраняем результаты для использования на следующих кадрах
                last_results = results
                
                # Статистика кадра
                occupied = sum(1 for box in results[0].boxes if int(box.cls[0]) == 0)
                free = sum(1 for box in results[0].boxes if int(box.cls[0]) == 1)
                total = occupied + free
                occupancy_rate = (occupied / total * 100) if total > 0 else 0
                
                frame_stats.append({
                    'frame': frame_number,
                    'occupied': occupied,
                    'free': free,
                    'total': total,
                    'occupancy_rate': round(occupancy_rate, 2)
                })
            
            # Отрисовка: используем последнюю детекцию для всех кадров
            if last_results is not None:
                annotated = draw_boxes_by_mode(frame, last_results, mode=mode)
                out.write(annotated)
            else:
                # Если ещё не было ни одной детекции - пишем оригинал
                out.write(frame)
            
            # Обновление прогресса
            if frames_written % 50 == 0:
                progress = (frame_number / total_frames) * 100
                video_processing_status['progress'] = int(progress)
                video_processing_status['current_frame'] = frame_number
                video_processing_status['message'] = f'Обработка: {progress:.1f}%'
                print(f"⏳ Прогресс: {progress:.1f}% ({frame_number}/{total_frames})")
            
            frames_written += 1
            frame_number += 1
        
        cap.release()
        out.release()
        
        # Вычисляем среднюю статистику
        if frame_stats:
            avg_occupied = sum(s['occupied'] for s in frame_stats) / len(frame_stats)
            avg_free = sum(s['free'] for s in frame_stats) / len(frame_stats)
            avg_total = sum(s['total'] for s in frame_stats) / len(frame_stats)
            avg_occupancy = sum(s['occupancy_rate'] for s in frame_stats) / len(frame_stats)
            
            result = {
                'success': True,
                'result_video': result_filename,
                'total_frames': total_frames,
                'processed_frames': len(frame_stats),
                'fps': output_fps,
                'mode': mode,
                'average_stats': {
                    'total_spots': round(avg_total, 1),
                    'occupied': round(avg_occupied, 1),
                    'free': round(avg_free, 1),
                    'occupancy_rate': round(avg_occupancy, 2)
                },
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            
            # Сохраняем статистику в JSON
            stats_path = os.path.join(app.config['RESULTS_FOLDER'], f'stats_{Path(filename).stem}.json')
            with open(stats_path, 'w', encoding='utf-8') as f:
                json.dump(result, f, ensure_ascii=False, indent=2)
            
            print(f"\n{'='*60}")
            print(f"✅ ВИДЕО ОБРАБОТАНО УСПЕШНО!")
            print(f"{'='*60}")
            print(f"📁 Сохранено: {result_path}")
            print(f"📊 Обработано кадров: {len(frame_stats)}")
            print(f"📈 Средняя статистика:")
            print(f"   • Всего мест: {avg_total:.1f}")
            print(f"   • Занято: {avg_occupied:.1f}")
            print(f"   • Свободно: {avg_free:.1f}")
            print(f"   • Заполненность: {avg_occupancy:.1f}%")
            print(f"{'='*60}\n")
            
            video_processing_status['is_processing'] = False
            video_processing_status['progress'] = 100
            video_processing_status['message'] = 'Готово!'
            
            return result
        
        video_processing_status['is_processing'] = False
        video_processing_status['message'] = 'Ошибка: нет данных'
        return None
        
    except Exception as e:
        print(f"❌ Ошибка обработки видео: {e}")
        import traceback
        traceback.print_exc()
        video_processing_status['is_processing'] = False
        video_processing_status['message'] = f'Ошибка: {str(e)}'
        return None


def process_batch_images_background(image_paths, mode='all', session_id=''):
    """
    Пакетная обработка нескольких изображений в многопоточном режиме
    
    Args:
        image_paths: Список путей к изображениям
        mode: Режим отображения
        session_id: ID сессии
    """
    global batch_processing_status
    
    try:
        batch_processing_status['is_processing'] = True
        batch_processing_status['progress'] = 0
        batch_processing_status['current_image'] = 0
        batch_processing_status['total_images'] = len(image_paths)
        batch_processing_status['message'] = 'Начало пакетной обработки...'
        batch_processing_status['results'] = []
        batch_processing_status['session_id'] = session_id
        
        print(f"\n{'='*60}")
        print(f"📊 ПАКЕТНАЯ ОБРАБОТКА: {len(image_paths)} фото")
        print(f"{'='*60}")
        print(f"🆔 Session ID: {session_id}")
        print(f"🎭 Режим: {DISPLAY_MODES.get(mode, mode)}")
        print(f"{'='*60}\n")
        
        # Многопоточная обработка с concurrent.futures
        from concurrent.futures import ThreadPoolExecutor, as_completed
        import threading
        
        results = []
        lock = threading.Lock()
        
        def process_single_image(image_path, index):
            """Обработка одного изображения"""
            try:
                # Проверяем флаг остановки
                if batch_processing_status['should_stop']:
                    print(f"⛔ Остановка пакетной обработки по запросу!")
                    return None
                
                print(f"⏳ [{index + 1}/{len(image_paths)}] Обработка: {Path(image_path).name}")
                
                # Анализируем изображение
                stats = analyze_image_api(image_path, mode=mode)
                
                if stats:
                    stats['index'] = index
                    stats['filename'] = Path(image_path).name
                    
                    with lock:
                        results.append(stats)
                        batch_processing_status['current_image'] = len(results)
                        progress = (len(results) / len(image_paths)) * 100
                        batch_processing_status['progress'] = int(progress)
                        batch_processing_status['message'] = f'Обработано: {len(results)}/{len(image_paths)}'
                    
                    print(f"✅ [{index + 1}/{len(image_paths)}] Готово: {Path(image_path).name} | Найдено: {stats['total_spots']} мест")
                    return stats
                else:
                    print(f"❌ [{index + 1}/{len(image_paths)}] Ошибка: {Path(image_path).name}")
                    return None
                    
            except Exception as e:
                print(f"❌ [{index + 1}/{len(image_paths)}] Исключение: {Path(image_path).name} - {str(e)}")
                return None
        
        # Используем максимум 4 потока для обработки
        max_workers = min(4, len(image_paths))
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Запускаем задачи
            futures = {executor.submit(process_single_image, path, idx): idx 
                      for idx, path in enumerate(image_paths)}
            
            # Ждём завершения всех задач
            for future in as_completed(futures):
                future.result()  # Получаем результат
        
        # Сортируем результаты по индексу
        results.sort(key=lambda x: x['index'] if x else 999)
        
        # Проверяем, была ли остановка
        if batch_processing_status['should_stop']:
            batch_processing_status['is_processing'] = False
            batch_processing_status['message'] = f'Остановлено! Обработано: {len(results)}/{len(image_paths)}'
            batch_processing_status['should_stop'] = False  # Сбрасываем флаг
            batch_processing_status['results'] = results
            print(f"\n⛔ ПАКЕТНАЯ ОБРАБОТКА ОСТАНОВЛЕНА")
            print(f"Обработано: {len(results)} из {len(image_paths)}")
            return results
        
        # Обновляем статус
        batch_processing_status['results'] = results
        batch_processing_status['is_processing'] = False
        batch_processing_status['progress'] = 100
        batch_processing_status['message'] = f'Готово! Обработано: {len(results)}/{len(image_paths)}'
        
        print(f"\n{'='*60}")
        print(f"✅ ПАКЕТНАЯ ОБРАБОТКА ЗАВЕРШЕНА")
        print(f"{'='*60}")
        print(f"📁 Успешно обработано: {len(results)} из {len(image_paths)}")
        print(f"{'='*60}\n")
        
        return results
        
    except Exception as e:
        print(f"❌ Ошибка пакетной обработки: {e}")
        import traceback
        traceback.print_exc()
        batch_processing_status['is_processing'] = False
        batch_processing_status['message'] = f'Ошибка: {str(e)}'
        return []


# ============== API ROUTES ==============

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/api/analyze_image', methods=['POST'])
def analyze_image():
    """API для анализа изображения"""
    if 'image' not in request.files:
        return jsonify({'error': 'Файл не предоставлен'}), 400
    
    file = request.files['image']
    
    if file.filename == '':
        return jsonify({'error': 'Файл не выбран'}), 400
    
    if not allowed_file(file.filename, 'image'):
        return jsonify({'error': 'Недопустимый формат изображения'}), 400
    
    try:
        # Сохраняем файл
        filename = secure_filename(file.filename)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"{timestamp}_{filename}"
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        # Получаем параметры
        mode = request.form.get('mode', 'all')
        conf = float(request.form.get('conf', DETECTION_SETTINGS['image_conf']))
        iou = float(request.form.get('iou', DETECTION_SETTINGS['iou']))
        
        # Анализируем
        stats = analyze_image_api(filepath, mode=mode, conf=conf, iou=iou)
        
        if stats is None:
            return jsonify({'error': 'Ошибка обработки изображения'}), 500
        
        return jsonify({
            'success': True,
            'stats': stats
        })
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'Ошибка: {str(e)}'}), 500


@app.route('/api/analyze_video', methods=['POST'])
def analyze_video():
    """API для анализа видео (фоновая обработка)"""
    if 'video' not in request.files:
        return jsonify({'error': 'Файл не предоставлен'}), 400
    
    file = request.files['video']
    
    if file.filename == '':
        return jsonify({'error': 'Файл не выбран'}), 400
    
    if not allowed_file(file.filename, 'video'):
        return jsonify({'error': 'Недопустимый формат видео'}), 400
    
    try:
        # Сохраняем файл
        filename = secure_filename(file.filename)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"{timestamp}_{filename}"
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        # Получаем параметры
        mode = request.form.get('mode', 'all')
        detect_interval = float(request.form.get('detect_interval', 1.0))  # Детекция каждую секунду по умолчанию
        
        # Запускаем обработку в отдельном потоке
        thread = threading.Thread(
            target=process_video_background,
            args=(filepath, mode, detect_interval)
        )
        thread.start()
        
        # Ждём немного, чтобы получить начальную информацию
        time.sleep(1)
        
        return jsonify({
            'success': True,
            'message': 'Видео отправлено на обработку',
            'status': video_processing_status
        })
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'Ошибка: {str(e)}'}), 500


@app.route('/api/video_status')
def video_status():
    """Получение статуса обработки видео"""
    return jsonify(video_processing_status)


@app.route('/results/<filename>')
def get_result(filename):
    """Получение результата (изображение или видео)"""
    return send_from_directory(app.config['RESULTS_FOLDER'], filename)


@app.route('/Logotip.png')
def get_logo():
    """Отдача логотипа из корня проекта"""
    return send_from_directory('.', 'Logotip.png')


@app.route('/Dizain.jpg')
def get_dizain():
    """Отдача дизайна из корня проекта"""
    return send_from_directory('.', 'Dizain.jpg')


@app.route('/api/analyze_batch', methods=['POST'])
def analyze_batch():
    """АPI для пакетной обработки нескольких изображений"""
    if 'images' not in request.files:
        return jsonify({'error': 'Файлы не предоставлены'}), 400
    
    files = request.files.getlist('images')
    
    if not files or len(files) == 0:
        return jsonify({'error': 'Файлы не выбраны'}), 400
    
    # Проверяем, что все файлы - изображения
    invalid_files = [f.filename for f in files if not allowed_file(f.filename, 'image')]
    if invalid_files:
        return jsonify({
            'error': f'Недопустимые форматы: {", ".join(invalid_files)}'
        }), 400
    
    try:
        # Сохраняем все файлы
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        session_id = f"batch_{timestamp}"
        image_paths = []
        
        for idx, file in enumerate(files):
            filename = secure_filename(file.filename)
            filename = f"{timestamp}_{idx:03d}_{filename}"
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            image_paths.append(filepath)
        
        # Получаем параметры
        mode = request.form.get('mode', 'all')
        
        # Запускаем пакетную обработку в отдельном потоке
        thread = threading.Thread(
            target=process_batch_images_background,
            args=(image_paths, mode, session_id)
        )
        thread.start()
        
        # Ждём немного, чтобы получить начальную информацию
        time.sleep(0.5)
        
        return jsonify({
            'success': True,
            'message': f'Пакетная обработка запущена: {len(files)} фото',
            'session_id': session_id,
            'total_images': len(files),
            'status': batch_processing_status
        })
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'Ошибка: {str(e)}'}), 500


@app.route('/api/batch_status')
def batch_status():
    """Получение статуса пакетной обработки"""
    return jsonify(batch_processing_status)


@app.route('/api/stop_batch', methods=['POST'])
def stop_batch():
    """Остановка пакетной обработки"""
    global batch_processing_status
    if batch_processing_status['is_processing']:
        batch_processing_status['should_stop'] = True
        print("⛔ Получен запрос на остановку пакетной обработки")
        return jsonify({'success': True, 'message': 'Остановка запрошена'})
    return jsonify({'success': False, 'message': 'Нет активной обработки'})


@app.route('/api/stop_video', methods=['POST'])
def stop_video():
    """Остановка обработки видео"""
    global video_processing_status
    if video_processing_status['is_processing']:
        video_processing_status['should_stop'] = True
        print("⛔ Получен запрос на остановку обработки видео")
        return jsonify({'success': True, 'message': 'Остановка запрошена'})
    return jsonify({'success': False, 'message': 'Нет активной обработки'})


@app.route('/api/download_batch_results', methods=['POST'])
def download_batch_results():
    """
    Создание и скачивание ZIP архива с всеми результатами пакетной обработки:
    - Все обработанные изображения
    - Все GeoJSON файлы
    """
    try:
        data = request.get_json()
        results = data.get('results', [])
        
        if not results:
            return jsonify({'success': False, 'error': 'Нет результатов для скачивания'}), 400
        
        # Создаём временный ZIP файл
        memory_file = io.BytesIO()
        
        with zipfile.ZipFile(memory_file, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for idx, result in enumerate(results, 1):
                result_image = result.get('result_image')
                geojson_file = result.get('geojson_file')
                
                # Добавляем изображение
                if result_image:
                    image_path = os.path.join(app.config['RESULTS_FOLDER'], result_image)
                    if os.path.exists(image_path):
                        # Сохраняем с номером для удобства
                        zipf.write(image_path, f'{idx:02d}_{result_image}')
                        print(f"✅ Добавлено изображение: {result_image}")
                
                # Добавляем GeoJSON
                if geojson_file:
                    geojson_path = os.path.join(app.config['RESULTS_FOLDER'], geojson_file)
                    if os.path.exists(geojson_path):
                        zipf.write(geojson_path, f'{idx:02d}_{geojson_file}')
                        print(f"✅ Добавлен GeoJSON: {geojson_file}")
        
        # Перемещаем указатель в начало
        memory_file.seek(0)
        
        print(f"\n🎉 ZIP архив с {len(results)} результатами готов к скачиванию!\n")
        
        return send_file(
            memory_file,
            mimetype='application/zip',
            as_attachment=True,
            download_name=f'parking_batch_results_{len(results)}_photos.zip'
        )
        
    except Exception as e:
        print(f"❌ Ошибка при создании ZIP: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/download_results', methods=['POST'])
def download_results():
    """
    Создание и скачивание ZIP архива с результатами:
    - Изображение с разметкой
    - GeoJSON файл с координатами
    """
    try:
        data = request.get_json()
        result_image = data.get('result_image')
        geojson_file = data.get('geojson_file')
        
        if not result_image:
            return jsonify({'error': 'Не указан файл результата'}), 400
        
        # Создаём временный ZIP архив в памяти
        memory_file = io.BytesIO()
        
        with zipfile.ZipFile(memory_file, 'w', zipfile.ZIP_DEFLATED) as zipf:
            # Добавляем изображение с разметкой
            image_path = os.path.join(app.config['RESULTS_FOLDER'], result_image)
            if os.path.exists(image_path):
                zipf.write(image_path, result_image)
            
            # Добавляем GeoJSON файл, если он есть
            if geojson_file:
                geojson_path = os.path.join(app.config['RESULTS_FOLDER'], geojson_file)
                if os.path.exists(geojson_path):
                    zipf.write(geojson_path, geojson_file)
        
        memory_file.seek(0)
        
        # Генерируем имя для архива
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        zip_filename = f'parking_analysis_{timestamp}.zip'
        
        return send_file(
            memory_file,
            mimetype='application/zip',
            as_attachment=True,
            download_name=zip_filename
        )
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'Ошибка создания архива: {str(e)}'}), 500


if __name__ == '__main__':
    print("\n" + "="*60)
    print("🚗 СИСТЕМА АНАЛИЗА ПАРКОВКИ ЗАПУЩЕНА")
    print("="*60)
    print(f"🌐 Откройте: http://localhost:5000")
    print(f"\n🤖 Загруженные модели:")
    print(f"   📷 Обычные фото: {MODEL_REGULAR_PATH}")
    print(f"   🛰️ Спутниковые снимки: {MODEL_SATELLITE_PATH}")
    print(f"\n📋 Настройки детекции:")
    print(f"   • Confidence (ОБЫЧНЫЕ ФОТО): {DETECTION_SETTINGS['image_conf']}")
    print(f"   • Confidence (СПУТНИКОВЫЕ TIF/TIFF): {DETECTION_SETTINGS['satellite_conf']} ⭐ НИЗКИЙ для максимального обнаружения")
    print(f"   • Confidence (ВИДЕО): {DETECTION_SETTINGS['video_conf']}")
    print(f"   • IoU: {DETECTION_SETTINGS['iou']}")
    print(f"   • Макс детекций: {DETECTION_SETTINGS['max_det']}")
    print(f"   • Детекция видео: каждую секунду")
    print(f"   • Контуры: адаптивные (TIF=1px прозрачные, остальные=3px яркие)")
    print(f"\n📁 Форматы файлов:")
    print(f"   📷 Обычные фото (best.pt, conf=0.30): {', '.join(REGULAR_IMAGE_EXTENSIONS)}")
    print(f"   🛰️ Спутниковые (best2.pt, conf=0.07): {', '.join(SATELLITE_IMAGE_EXTENSIONS)}")
    print(f"\n🎨 Доступные режимы:")
    for mode_key, mode_name in DISPLAY_MODES.items():
        print(f"   • {mode_key}: {mode_name}")
    print(f"\n💡 Классы:")
    for cls_id, name in CLASS_NAMES.items():
        print(f"   • {cls_id}: {name}")
    print(f"\n⚠️ ВАЖНО:")
    print(f"   • Порог для спутниковых снимков: 0.07 (низкий для максимального обнаружения)")
    print(f"   • Контуры:")
    print(f"      - Спутниковые TIF/TIFF: тонкие (1px) прозрачные (40%)")
    print(f"      - Обычные фото PNG/JPG: толстые (3px) яркие")
    print("="*60 + "\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000, threaded=True)







